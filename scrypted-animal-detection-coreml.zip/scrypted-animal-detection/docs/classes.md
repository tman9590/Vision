# Animal Classes Reference

The model detects 20 animal classes. Class IDs below correspond to the index in `config.json → classes`.

| ID | Class | Colour | Primary Data Source | Notes |
|---|---|---|---|---|
| 0 | bear | `#8B0000` | COCO + Open Images | Black, brown, and polar bears |
| 1 | bird | `#1E90FF` | COCO | Generic bird; works on most species |
| 2 | cat | `#FF69B4` | COCO | Domestic cats; also works on bobcats |
| 3 | cow | `#8B4513` | COCO | Cattle; may generalise to bison |
| 4 | deer | `#228B22` | Open Images | Whitetail, mule deer, fawn |
| 5 | dog | `#FFA500` | COCO | Domestic dogs; all breeds |
| 6 | elephant | `#708090` | COCO | African & Asian |
| 7 | fox | `#FF4500` | Open Images | Red fox; limited training data |
| 8 | horse | `#D2691E` | COCO | Horse, pony |
| 9 | monkey | `#9ACD32` | COCO | Various primates |
| 10 | mouse | `#A9A9A9` | COCO | Mouse, rat |
| 11 | raccoon | `#4B0082` | Open Images | Common raccoon |
| 12 | rabbit | `#FFD700` | COCO | Domestic & wild |
| 13 | sheep | `#F5F5F5` | COCO | Sheep, goat |
| 14 | skunk | `#2F4F4F` | Open Images | Striped skunk; limited data |
| 15 | squirrel | `#CD853F` | Open Images | Grey & red squirrel |
| 16 | wolf | `#6A5ACD` | Open Images | Grey wolf, timber wolf |
| 17 | coyote | `#DAA520` | Open Images | May be confused with wolf/dog |
| 18 | turkey | `#B8860B` | Open Images | Wild turkey |
| 19 | duck | `#008B8B` | Open Images | Mallard & common ducks |

## Known Limitations

- **Fox / skunk / coyote / turkey** have fewer training examples in public datasets — expect lower recall on these classes.
- **Bird** is a coarse class; it will not distinguish species.
- **Dog vs. coyote vs. wolf** — these are visually similar. At distance or low resolution, misclassification is possible. Use zone-based automations to reduce false alerts (e.g., only alert for `coyote` detections in the backyard zone, not the driveway).

## Improving Specific Classes

To improve accuracy for a specific class:
1. Collect 500–1 000 additional annotated images for that class
2. Add them to `data/train/images/` with matching label files
3. Re-run `scripts/train.py` — the model will pick up the new data
4. Re-export with `scripts/export_coreml.py`
