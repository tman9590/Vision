# Scrypted Deployment Guide

## Prerequisites

- Scrypted ≥ 0.3.0 running on **macOS 13+** with Apple Silicon
- The `AnimalDetector.mlpackage` already exported (see [training.md](training.md))
- Python 3.10+ available in the Scrypted Python runtime

---

## Step 1 — Install the Plugin

### Option A: From repository (development)

1. Clone this repository onto your Scrypted host:
   ```bash
   git clone https://github.com/your-username/scrypted-animal-detection-coreml
   ```
2. In Scrypted: **Settings → Plugins → Install Plugin from Local Path**
3. Point the path to the repository root

### Option B: From GitHub Release

1. Download `AnimalDetector-vX.Y.Z.zip` from the [Releases page](https://github.com/your-username/scrypted-animal-detection-coreml/releases)
2. Unzip it — you get `AnimalDetector.mlpackage` and `manifest.json`
3. Place both in the plugin's `model/` directory
4. Restart Scrypted

---

## Step 2 — Assign to Cameras

1. Open your camera in Scrypted
2. Go to **Extensions → Object Detection**
3. Select **Animal Detection (CoreML)** from the plugin dropdown
4. Click **Save**

---

## Step 3 — Configure Settings

In the plugin settings panel:

| Setting | Recommended | Notes |
|---|---|---|
| Confidence | 0.40 | Lower for backyard cameras, raise to reduce false positives |
| IoU Threshold | 0.45 | Leave default unless you see duplicate boxes |
| Compute Units | cpuAndNeuralEngine | Best for Apple Silicon |
| Enabled Classes | *(empty = all)* | Set specific classes to reduce noise |
| Min Box Area | 400 | Ignores detections smaller than ~20×20 px |

---

## Step 4 — Set Up Automations

In Scrypted's Automation plugin, create a rule:

**Trigger:** `Animal Detection → Detection Event`  
**Condition:** `className in ["bear", "deer", "coyote"]`  
**Action:** Send notification / record clip / trigger light

---

## Performance Tuning

### Throughput vs. accuracy

| Compute Units | Latency | Power |
|---|---|---|
| `cpuOnly` | ~40 ms | Low |
| `cpuAndGPU` | ~15 ms | Medium |
| `cpuAndNeuralEngine` | ~8 ms | Very low |
| `all` | ~7 ms | Medium |

For always-on NVR use, `cpuAndNeuralEngine` is the best balance.

### Frame rate

The plugin processes frames as fast as Scrypted delivers them. To limit CPU usage, lower the camera's analysis frame rate in Scrypted's camera settings (e.g., analyse every 2nd frame at 15 FPS → effectively 7.5 FPS analysis).

---

## Troubleshooting

**Plugin loads but no detections appear**
- Check the confidence threshold — try 0.25 temporarily
- Verify the `.mlpackage` is in `model/` and restart Scrypted
- Check Scrypted logs for Python errors

**`coremltools` import error**
- Ensure Scrypted's Python runtime is the system Python on macOS, not a Homebrew venv without coremltools

**High CPU usage**
- Switch compute units to `cpuAndNeuralEngine` to offload to the Neural Engine
- Reduce the camera analysis frame rate

**False positives (bushes detected as animals)**
- Raise `confidence_threshold` to 0.55
- Enable only the classes you care about in **Enabled Classes**
