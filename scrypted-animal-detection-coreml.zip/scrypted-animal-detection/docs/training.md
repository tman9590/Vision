# Training Guide

## Overview

The animal detector is built on **YOLOv8n** (nano) — the smallest and fastest variant in the YOLOv8 family. It is fine-tuned on a curated dataset of 20 animal classes drawn from COCO 2017 and Open Images v7.

---

## Environment Setup

```bash
# macOS (recommended for CoreML export)
brew install python@3.12
pip install ultralytics coremltools opencv-python-headless

# Linux (for training only)
pip install ultralytics opencv-python-headless onnxruntime
```

---

## Dataset Preparation

The `prepare_dataset.py` script handles everything:

```bash
python scripts/prepare_dataset.py \
  --output_dir data/ \
  --classes all \
  --val_split 0.15 \
  --test_split 0.05 \
  --max_per_class 2000
```

This creates:
```
data/
├── dataset.yaml
├── train/images/   (~28 000 images)
├── train/labels/
├── val/images/     (~6 000 images)
├── val/labels/
├── test/images/    (~2 000 images)
└── test/labels/
```

### Custom data

Add your own images by placing them in `data/train/images/` with matching YOLO-format `.txt` label files in `data/train/labels/`. Each label file contains one row per object:

```
<class_id> <cx> <cy> <w> <h>
```

All values are normalised to [0, 1].  Class IDs follow the order in `config.json → classes`.

---

## Training

### Standard run

```bash
python scripts/train.py \
  --data data/dataset.yaml \
  --epochs 100 \
  --batch 16 \
  --device mps        # Apple Silicon GPU; use cuda for NVIDIA; leave empty for auto
```

### Resume an interrupted run

```bash
python scripts/train.py --resume runs/train/weights/last.pt
```

### Key hyperparameters (all editable in config.json)

| Parameter | Default | Notes |
|---|---|---|
| `epochs` | 100 | More epochs → higher accuracy, longer time |
| `batch` | 16 | Increase for faster training if VRAM allows |
| `lr0` | 0.001 | Initial learning rate |
| `patience` | 20 | Early stopping patience |
| `mosaic` | 1.0 | Mosaic augmentation probability |
| `mixup` | 0.1 | MixUp augmentation alpha |
| `imgsz` | 640 | Training image size (must match export) |

---

## Monitoring

Training metrics are logged to `runs/train/`:

```
runs/train/
├── weights/
│   ├── best.pt       ← use this for export
│   └── last.pt
├── results.csv
├── confusion_matrix.png
├── PR_curve.png
└── labels.jpg
```

Open `results.csv` in any spreadsheet tool or use TensorBoard:

```bash
pip install tensorboard
tensorboard --logdir runs/train
```

---

## Expected Results

After 100 epochs on a balanced dataset of 2 000 images/class:

| Metric | Expected |
|---|---|
| mAP@0.5 | 0.70 – 0.78 |
| mAP@0.5:0.95 | 0.48 – 0.56 |
| Training time (M2 Pro, MPS) | ~2 – 4 hours |
| Training time (NVIDIA RTX 3090) | ~45 – 90 min |

Classes with limited COCO representation (fox, skunk, coyote) typically score lower. Supplement with Open Images data for those classes.

---

## Next Steps

After training:

1. **Evaluate** → `python scripts/evaluate.py --weights runs/train/weights/best.pt --data data/dataset.yaml`
2. **Export** → `python scripts/export_coreml.py --weights runs/train/weights/best.pt`
3. **Test** → `python scripts/inference.py --image test.jpg`
