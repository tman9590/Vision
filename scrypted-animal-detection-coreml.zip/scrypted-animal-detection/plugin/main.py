#!/usr/bin/env python3
"""
plugin/main.py
--------------
Scrypted NVR plugin for CoreML animal detection.

This file implements the Scrypted ObjectDetection interface and is loaded
by the Scrypted plugin runtime.  It bridges the CoreML inference engine
(scripts/inference.py) with Scrypted's camera pipeline.

Plugin manifest is in plugin/package.json.
"""

from __future__ import annotations

import asyncio
import json
import sys
import time
from pathlib import Path
from typing import Any, Optional

# Ensure the project root is on the Python path so we can import inference.py
ROOT = Path(__file__).parent.parent
sys.path.insert(0, str(ROOT / "scripts"))

try:
    from inference import AnimalDetector, InferenceResult
    _DETECTOR_AVAILABLE = True
except Exception as e:
    print(f"⚠  Could not import AnimalDetector: {e}")
    _DETECTOR_AVAILABLE = False

try:
    import numpy as np
    import cv2
    _CV2_AVAILABLE = True
except ImportError:
    _CV2_AVAILABLE = False

CONFIG_PATH = ROOT / "config.json"


def _load_config() -> dict:
    with open(CONFIG_PATH) as f:
        return json.load(f)


# ── Scrypted ObjectDetection interface stubs ─────────────────────────────────
# In real Scrypted, these come from the scrypted_sdk package.
# We define lightweight stubs so the module can be tested outside Scrypted.

try:
    from scrypted_sdk import (
        ScryptedDeviceBase,
        ObjectDetection,
        ObjectDetectionTypes,
        ObjectsDetected,
        MediaObject,
        Setting,
        Settings,
        SettingValue,
        ScryptedMimeTypes,
    )
    _SCRYPTED_SDK = True
except ImportError:
    _SCRYPTED_SDK = False

    class ScryptedDeviceBase:
        def __init__(self): self.storage = {}

    class ObjectDetection:
        pass

    class Settings:
        pass


# ── Plugin class ─────────────────────────────────────────────────────────────

class AnimalDetectionPlugin(ScryptedDeviceBase, ObjectDetection, Settings):
    """
    Scrypted plugin that runs the CoreML animal detector on camera frames.

    Settings exposed to the Scrypted UI:
        • confidence_threshold   — min score to report
        • iou_threshold          — NMS IoU threshold
        • compute_units          — Apple compute unit selection
        • enabled_classes        — subset of classes to forward
        • min_box_area           — discard tiny detections
    """

    def __init__(self, nativeId: Optional[str] = None):
        super().__init__()
        self.cfg      = _load_config()
        self._detector: Optional[AnimalDetector] = None
        self._load_detector()

    # ── Settings ─────────────────────────────────────────────────────────────

    def _get_setting(self, key: str):
        stored = self.storage.get(key)
        if stored is not None:
            return stored
        return self.cfg["scrypted"]["settings"][key]["default"]

    async def getSettings(self) -> list:
        raw    = self.cfg["scrypted"]["settings"]
        result = []
        for key, meta in raw.items():
            result.append({
                "key":         key,
                "title":       meta["title"],
                "description": meta.get("description", ""),
                "type":        meta["type"],
                "value":       self._get_setting(key),
                **({"choices": meta["choices"]} if "choices" in meta else {}),
                **({"min": meta["min"], "max": meta["max"]} if "min" in meta else {}),
            })
        return result

    async def putSetting(self, key: str, value) -> None:
        self.storage[key] = value
        # Reload detector when inference-affecting settings change
        if key in ("confidence_threshold", "iou_threshold", "compute_units"):
            self._load_detector()

    # ── Detector lifecycle ────────────────────────────────────────────────────

    def _load_detector(self):
        if not _DETECTOR_AVAILABLE:
            print("⚠  AnimalDetector not available — check dependencies")
            return
        try:
            self._detector = AnimalDetector(
                conf_threshold = float(self._get_setting("confidence_threshold")),
                iou_threshold  = float(self._get_setting("iou_threshold")),
                compute_units  = str(self._get_setting("compute_units")),
            )
            print("✓ AnimalDetector loaded successfully")
        except Exception as e:
            print(f"✗ Failed to load AnimalDetector: {e}")
            self._detector = None

    # ── ObjectDetection interface ─────────────────────────────────────────────

    async def getDetectionModel(self) -> dict:
        return {
            "name":      self.cfg["model"]["name"],
            "classes":   self.cfg["classes"],
            "inputSize": self.cfg["model"]["input_size"],
        }

    async def detectObjects(self, mediaObject, session=None) -> dict:
        """
        Called by Scrypted for each camera frame.

        mediaObject — Scrypted MediaObject wrapping a JPEG/PNG frame.
        Returns dict matching Scrypted ObjectsDetected schema.
        """
        if self._detector is None:
            return {"detections": [], "timestamp": int(time.time() * 1000)}

        try:
            frame = await self._media_to_bgr(mediaObject)
        except Exception as e:
            print(f"⚠  Could not decode frame: {e}")
            return {"detections": [], "timestamp": int(time.time() * 1000)}

        result = self._run_detection(frame)
        return self._format_scrypted_response(result)

    # ── Helpers ───────────────────────────────────────────────────────────────

    async def _media_to_bgr(self, mediaObject) -> "np.ndarray":
        """Decode Scrypted MediaObject → OpenCV BGR array."""
        if not _CV2_AVAILABLE:
            raise RuntimeError("OpenCV not available")

        # In real Scrypted the SDK provides mediaManager.convertMediaObjectToBuffer
        raw   = await mediaObject.getData()
        arr   = np.frombuffer(raw, dtype=np.uint8)
        frame = cv2.imdecode(arr, cv2.IMREAD_COLOR)
        if frame is None:
            raise ValueError("cv2.imdecode returned None — invalid image data")
        return frame

    def _run_detection(self, frame: "np.ndarray") -> InferenceResult:
        return self._detector.detect(frame)

    def _format_scrypted_response(self, result: InferenceResult) -> dict:
        """Convert InferenceResult → Scrypted ObjectsDetected dict."""
        enabled = set(self._get_setting("enabled_classes") or [])
        min_area= float(self._get_setting("min_box_area") or 0)

        detections = []
        for det in result.detections:
            if enabled and det.class_name not in enabled:
                continue
            x1, y1, x2, y2 = det.bbox
            area = (x2 - x1) * (y2 - y1)
            if area < min_area:
                continue
            detections.append(det.to_scrypted())

        return {
            "detections": detections,
            "timestamp":  int(time.time() * 1000),
            "running":    True,
        }


# ── Scrypted entry point ──────────────────────────────────────────────────────

def create_scrypted_plugin():
    """Called by the Scrypted runtime to instantiate the plugin."""
    return AnimalDetectionPlugin()


# ── Dev / debug mode ─────────────────────────────────────────────────────────

if __name__ == "__main__":
    import argparse

    p = argparse.ArgumentParser(description="Test plugin against a local image")
    p.add_argument("--image", required=True, help="Path to test image")
    args = p.parse_args()

    plugin = AnimalDetectionPlugin()

    if not _CV2_AVAILABLE:
        print("OpenCV not available — cannot run standalone test")
        sys.exit(1)

    frame  = cv2.imread(args.image)
    result = plugin._run_detection(frame)

    print(json.dumps(result.to_dict(), indent=2))
    annotated = plugin._detector.draw_detections(frame, result)
    out_path  = Path(args.image).with_stem(Path(args.image).stem + "_detected")
    cv2.imwrite(str(out_path), annotated)
    print(f"Annotated image saved to {out_path}")
