#!/usr/bin/env python3
"""
evaluate.py
-----------
Evaluates a trained checkpoint on the test split and produces:
  • Per-class precision, recall, and mAP@0.5
  • Summary table printed to stdout
  • JSON results file saved to runs/eval/results.json
  • Confusion matrix image saved to runs/eval/confusion_matrix.png

Requirements:
    pip install ultralytics matplotlib

Usage:
    python scripts/evaluate.py --weights runs/train/weights/best.pt \
                               --data data/dataset.yaml
"""

import argparse
import json
import sys
from pathlib import Path

import numpy as np

ROOT = Path(__file__).parent.parent


def parse_args():
    p = argparse.ArgumentParser(description="Evaluate animal detector")
    p.add_argument("--weights", required=True, help="Path to best.pt")
    p.add_argument("--data",    required=True, help="Path to dataset.yaml")
    p.add_argument("--split",   default="test", choices=["val", "test"])
    p.add_argument("--imgsz",   type=int, default=640)
    p.add_argument("--batch",   type=int, default=16)
    p.add_argument("--conf",    type=float, default=0.001, help="Low conf for full PR curve")
    p.add_argument("--iou",     type=float, default=0.60)
    p.add_argument("--device",  default="", help="cuda / mps / cpu")
    p.add_argument("--output",  default="runs/eval", help="Output directory")
    p.add_argument("--verbose", action="store_true", default=True)
    return p.parse_args()


def load_config() -> dict:
    with open(ROOT / "config.json") as f:
        return json.load(f)


def run_validation(args, cfg: dict):
    try:
        from ultralytics import YOLO
    except ImportError:
        sys.exit("✗ ultralytics not installed. Run: pip install ultralytics")

    model   = YOLO(args.weights)
    metrics = model.val(
        data    = args.data,
        split   = args.split,
        imgsz   = args.imgsz,
        batch   = args.batch,
        conf    = args.conf,
        iou     = args.iou,
        device  = args.device or None,
        verbose = args.verbose,
        plots   = True,
        save_json = True,
        project = args.output,
        name    = "results",
    )
    return metrics


def format_results(metrics, cfg: dict) -> dict:
    """Extract per-class and overall stats into a clean dict."""
    names   = cfg["classes"]
    box     = metrics.box

    # Per-class arrays from ultralytics metrics object
    # These are aligned to the model's class list
    per_class = []
    for i, name in enumerate(names):
        try:
            p  = float(box.p[i])   if hasattr(box, "p")   and len(box.p)   > i else None
            r  = float(box.r[i])   if hasattr(box, "r")   and len(box.r)   > i else None
            ap = float(box.ap[i])  if hasattr(box, "ap")  and len(box.ap)  > i else None
            f1 = (2 * p * r / (p + r + 1e-9)) if (p is not None and r is not None) else None
        except Exception:
            p = r = ap = f1 = None

        per_class.append({
            "class":      name,
            "precision":  round(p,  4) if p  is not None else "N/A",
            "recall":     round(r,  4) if r  is not None else "N/A",
            "mAP50":      round(ap, 4) if ap is not None else "N/A",
            "f1":         round(f1, 4) if f1 is not None else "N/A",
        })

    overall = {
        "mAP50":      round(float(box.map50),  4),
        "mAP50_95":   round(float(box.map),    4),
        "precision":  round(float(box.mp),     4),
        "recall":     round(float(box.mr),     4),
    }

    return {"overall": overall, "per_class": per_class}


def print_table(results: dict):
    overall = results["overall"]
    rows    = results["per_class"]

    print("\n" + "═" * 72)
    print(f"{'CLASS':<14}  {'PRECISION':>10}  {'RECALL':>8}  {'mAP@0.5':>9}  {'F1':>6}")
    print("─" * 72)

    for r in rows:
        p  = f"{r['precision']:.4f}" if isinstance(r["precision"], float) else str(r["precision"])
        rc = f"{r['recall']:.4f}"    if isinstance(r["recall"],    float) else str(r["recall"])
        ap = f"{r['mAP50']:.4f}"     if isinstance(r["mAP50"],     float) else str(r["mAP50"])
        f1 = f"{r['f1']:.4f}"        if isinstance(r["f1"],        float) else str(r["f1"])
        print(f"{r['class']:<14}  {p:>10}  {rc:>8}  {ap:>9}  {f1:>6}")

    print("─" * 72)
    print(
        f"{'ALL':<14}  "
        f"{overall['precision']:>10.4f}  "
        f"{overall['recall']:>8.4f}  "
        f"{overall['mAP50']:>9.4f}  "
        f"{'':>6}"
    )
    print(f"\nmAP@0.5:0.95 = {overall['mAP50_95']:.4f}")
    print("═" * 72 + "\n")


def save_results(results: dict, output_dir: Path):
    output_dir.mkdir(parents=True, exist_ok=True)
    out_path = output_dir / "results.json"
    out_path.write_text(json.dumps(results, indent=2))
    print(f"✓ Saved evaluation results to {out_path}")


def plot_per_class_map(results: dict, output_dir: Path):
    try:
        import matplotlib.pyplot as plt
    except ImportError:
        print("⚠  matplotlib not installed — skipping bar chart")
        return

    rows   = [r for r in results["per_class"] if isinstance(r["mAP50"], float)]
    names  = [r["class"] for r in rows]
    maps   = [r["mAP50"] for r in rows]
    colors = ["#4C9BE8" if m >= 0.5 else "#E85C4C" for m in maps]

    fig, ax = plt.subplots(figsize=(12, 5))
    bars = ax.bar(names, maps, color=colors, edgecolor="white", linewidth=0.5)
    ax.axhline(0.5, color="#888", linestyle="--", linewidth=1, label="0.5 threshold")
    ax.set_ylim(0, 1.05)
    ax.set_xlabel("Animal Class")
    ax.set_ylabel("mAP@0.5")
    ax.set_title("Per-Class mAP@0.5 — Animal Detector")
    ax.legend()
    plt.xticks(rotation=45, ha="right")
    plt.tight_layout()

    chart_path = output_dir / "per_class_map.png"
    plt.savefig(chart_path, dpi=150)
    plt.close()
    print(f"✓ Saved per-class mAP chart to {chart_path}")


def main():
    args    = parse_args()
    cfg     = load_config()
    out_dir = Path(args.output)

    print(f"Evaluating: {args.weights}")
    print(f"Dataset:    {args.data}  [{args.split}]")
    print()

    metrics = run_validation(args, cfg)
    results = format_results(metrics, cfg)

    print_table(results)
    save_results(results, out_dir)
    plot_per_class_map(results, out_dir)

    # Exit non-zero if overall mAP is below 0.40 (useful in CI)
    if results["overall"]["mAP50"] < 0.40:
        print(f"⚠  mAP@0.5 {results['overall']['mAP50']:.4f} is below 0.40 threshold")
        sys.exit(1)

    print("✅ Evaluation passed")


if __name__ == "__main__":
    main()
