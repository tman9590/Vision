#!/usr/bin/env python3
"""
export_coreml.py
----------------
Converts a trained YOLOv8 .pt checkpoint to an Apple CoreML .mlpackage
ready for use in the Scrypted NVR plugin.

Conversion pipeline:
    best.pt  →  best.onnx  →  AnimalDetector.mlpackage

Requirements:
    pip install ultralytics coremltools onnx

Usage:
    python scripts/export_coreml.py --weights runs/train/weights/best.pt
    python scripts/export_coreml.py --weights runs/train/weights/best.pt --half   # FP16
"""

import argparse
import json
import shutil
import sys
from pathlib import Path

ROOT        = Path(__file__).parent.parent
CONFIG_PATH = ROOT / "config.json"
MODEL_DIR   = ROOT / "model"


def load_config() -> dict:
    with open(CONFIG_PATH) as f:
        return json.load(f)


def parse_args(cfg: dict):
    m = cfg["model"]
    e = cfg["export"]

    p = argparse.ArgumentParser(description="Export YOLOv8 → CoreML for Scrypted")
    p.add_argument("--weights",  required=True,           help="Path to best.pt")
    p.add_argument("--output",   default=str(MODEL_DIR),  help="Output directory")
    p.add_argument("--imgsz",    type=int,   default=m["input_size"][0])
    p.add_argument("--half",     action="store_true",     help="FP16 export (Apple Silicon)")
    p.add_argument("--nms",      action="store_true", default=e["nms"],
                   help="Bake NMS into the CoreML model")
    p.add_argument("--conf",     type=float, default=m["confidence_threshold"])
    p.add_argument("--iou",      type=float, default=m["iou_threshold"])
    p.add_argument("--compute",  default=m["compute_units"],
                   choices=["cpuOnly", "cpuAndGPU", "all", "cpuAndNeuralEngine"])
    return p.parse_args()


def export_yolo_to_coreml(weights: str, args, cfg: dict):
    """Use Ultralytics built-in CoreML exporter."""
    try:
        from ultralytics import YOLO
    except ImportError:
        sys.exit("✗ ultralytics not installed. Run: pip install ultralytics")

    print(f"Loading model from {weights} …")
    model = YOLO(weights)

    print("Exporting to CoreML …")
    export_path = model.export(
        format   = "coreml",
        imgsz    = args.imgsz,
        half     = args.half,
        nms      = args.nms,
        conf     = args.conf,
        iou      = args.iou,
        simplify = cfg["export"]["simplify"],
    )
    return Path(export_path)


def post_process_mlpackage(src: Path, dst_dir: Path, cfg: dict):
    """
    Annotate the .mlpackage with metadata, copy to model/ directory,
    and write a companion manifest JSON.
    """
    try:
        import coremltools as ct
    except ImportError:
        print("⚠  coremltools not installed — skipping metadata annotation")
        print("   Run: pip install coremltools")
        dst = dst_dir / cfg["model"]["filename"]
        if src != dst:
            shutil.copytree(src, dst, dirs_exist_ok=True)
        return dst

    print("Annotating CoreML model metadata …")
    mlmodel = ct.models.MLModel(str(src))

    spec = mlmodel.get_spec()
    desc = spec.description

    # ── Model metadata ───────────────────────────────────────────────────────
    desc.metadata.shortDescription = (
        "Animal detector for Scrypted NVR. "
        "YOLOv8 backbone converted to CoreML."
    )
    desc.metadata.author  = "scrypted-animal-detection"
    desc.metadata.license = "MIT"
    desc.metadata.versionString = cfg["meta"]["created"]
    desc.metadata.userDefinedMetadata["classes"]    = json.dumps(cfg["classes"])
    desc.metadata.userDefinedMetadata["conf_thresh"] = str(cfg["model"]["confidence_threshold"])
    desc.metadata.userDefinedMetadata["iou_thresh"]  = str(cfg["model"]["iou_threshold"])
    desc.metadata.userDefinedMetadata["input_size"]  = json.dumps(cfg["model"]["input_size"])

    # ── Compute units ────────────────────────────────────────────────────────
    compute_map = {
        "cpuOnly":           ct.ComputeUnit.CPU_ONLY,
        "cpuAndGPU":         ct.ComputeUnit.CPU_AND_GPU,
        "all":               ct.ComputeUnit.ALL,
        "cpuAndNeuralEngine":ct.ComputeUnit.CPU_AND_NE,
    }
    compute = compute_map.get(cfg["model"]["compute_units"], ct.ComputeUnit.CPU_AND_NE)
    annotated = ct.models.MLModel(spec, compute_units=compute)

    dst = dst_dir / cfg["model"]["filename"]
    dst_dir.mkdir(parents=True, exist_ok=True)
    annotated.save(str(dst))
    print(f"✓ Saved annotated model to {dst}")

    # ── Manifest ─────────────────────────────────────────────────────────────
    manifest = {
        "model_file":    cfg["model"]["filename"],
        "classes":       cfg["classes"],
        "input_size":    cfg["model"]["input_size"],
        "conf_threshold":cfg["model"]["confidence_threshold"],
        "iou_threshold": cfg["model"]["iou_threshold"],
        "compute_units": cfg["model"]["compute_units"],
        "exported_from": str(src),
        "framework":     "YOLOv8 → CoreML",
    }
    manifest_path = dst_dir / "manifest.json"
    manifest_path.write_text(json.dumps(manifest, indent=2))
    print(f"✓ Wrote {manifest_path}")

    return dst


def main():
    cfg  = load_config()
    args = parse_args(cfg)

    weights  = Path(args.weights)
    dst_dir  = Path(args.output)

    if not weights.exists():
        sys.exit(f"✗ Weights not found: {weights}")

    # Export
    mlpackage_path = export_yolo_to_coreml(str(weights), args, cfg)

    # Post-process & copy
    final_path = post_process_mlpackage(mlpackage_path, dst_dir, cfg)

    print("\n" + "═" * 60)
    print("Export complete!")
    print(f"  CoreML package : {final_path}")
    print(f"  Classes        : {len(cfg['classes'])}")
    print(f"  Input size     : {args.imgsz}×{args.imgsz}")
    print(f"  Compute units  : {cfg['model']['compute_units']}")
    print("═" * 60)
    print("\nDrop the .mlpackage into your Scrypted plugin and restart.")


if __name__ == "__main__":
    main()
