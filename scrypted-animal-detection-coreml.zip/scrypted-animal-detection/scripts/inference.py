#!/usr/bin/env python3
"""
inference.py
------------
CoreML inference engine for the Scrypted NVR animal detection plugin.

This module is imported by the Scrypted plugin (plugin/main.py) and can
also be run standalone for quick testing:

    python scripts/inference.py --image /path/to/frame.jpg
    python scripts/inference.py --camera rtsp://192.168.1.100/stream
"""

from __future__ import annotations

import argparse
import json
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

import cv2
import numpy as np

ROOT        = Path(__file__).parent.parent
CONFIG_PATH = ROOT / "config.json"
MODEL_PATH  = ROOT / "model" / "AnimalDetector.mlpackage"

# ── Data structures ──────────────────────────────────────────────────────────

@dataclass
class Detection:
    class_name: str
    class_id:   int
    confidence: float
    bbox:       tuple[float, float, float, float]  # x1, y1, x2, y2 (pixel coords)
    bbox_norm:  tuple[float, float, float, float]  # normalised 0-1

    def to_dict(self) -> dict:
        return {
            "class":      self.class_name,
            "class_id":   self.class_id,
            "confidence": round(float(self.confidence), 4),
            "bbox":       [round(v, 1) for v in self.bbox],
            "bbox_norm":  [round(v, 6) for v in self.bbox_norm],
        }

    def to_scrypted(self) -> dict:
        """Format expected by Scrypted ObjectDetection interface."""
        x1, y1, x2, y2 = self.bbox
        return {
            "className":  self.class_name,
            "score":      float(self.confidence),
            "boundingBox": {
                "x": x1, "y": y1,
                "width":  x2 - x1,
                "height": y2 - y1,
            },
        }


@dataclass
class InferenceResult:
    detections:  list[Detection] = field(default_factory=list)
    latency_ms:  float = 0.0
    image_w:     int   = 0
    image_h:     int   = 0

    @property
    def animals_present(self) -> list[str]:
        return sorted({d.class_name for d in self.detections})

    def to_dict(self) -> dict:
        return {
            "detections":      [d.to_dict() for d in self.detections],
            "animals_present": self.animals_present,
            "count":           len(self.detections),
            "latency_ms":      round(self.latency_ms, 2),
        }


# ── Preprocessor ────────────────────────────────────────────────────────────

class Preprocessor:
    """Letterbox resize + RGB conversion matching YOLOv8 training pipeline."""

    def __init__(self, target: int = 640):
        self.target = target

    def __call__(self, bgr: np.ndarray) -> tuple[np.ndarray, float, tuple[int, int]]:
        """
        Returns:
            blob    — float32 NCHW tensor normalised to [0, 1]
            scale   — resize scale factor (used to map boxes back)
            padding — (pad_w, pad_h) in pixels
        """
        h, w = bgr.shape[:2]
        scale = self.target / max(h, w)
        new_w = int(w * scale)
        new_h = int(h * scale)

        resized = cv2.resize(bgr, (new_w, new_h), interpolation=cv2.INTER_LINEAR)
        rgb     = cv2.cvtColor(resized, cv2.COLOR_BGR2RGB)

        pad_w = self.target - new_w
        pad_h = self.target - new_h

        padded = cv2.copyMakeBorder(
            rgb, 0, pad_h, 0, pad_w,
            cv2.BORDER_CONSTANT, value=(114, 114, 114)
        )

        blob = padded.astype(np.float32) / 255.0
        blob = np.transpose(blob, (2, 0, 1))[np.newaxis]  # → NCHW

        return blob, scale, (pad_w, pad_h)


# ── Postprocessor ────────────────────────────────────────────────────────────

def xywh_to_xyxy(boxes_xywh: np.ndarray) -> np.ndarray:
    """Convert [cx, cy, w, h] → [x1, y1, x2, y2]."""
    out = np.empty_like(boxes_xywh)
    out[..., 0] = boxes_xywh[..., 0] - boxes_xywh[..., 2] / 2
    out[..., 1] = boxes_xywh[..., 1] - boxes_xywh[..., 3] / 2
    out[..., 2] = boxes_xywh[..., 0] + boxes_xywh[..., 2] / 2
    out[..., 3] = boxes_xywh[..., 1] + boxes_xywh[..., 3] / 2
    return out


def nms(boxes: np.ndarray, scores: np.ndarray, iou_thresh: float) -> list[int]:
    """Pure-NumPy NMS (fallback when model does not include NMS layer)."""
    x1, y1, x2, y2 = boxes[:, 0], boxes[:, 1], boxes[:, 2], boxes[:, 3]
    areas  = (x2 - x1) * (y2 - y1)
    order  = scores.argsort()[::-1]
    keep   = []

    while order.size:
        i = order[0]
        keep.append(int(i))
        if order.size == 1:
            break
        inter_x1 = np.maximum(x1[i], x1[order[1:]])
        inter_y1 = np.maximum(y1[i], y1[order[1:]])
        inter_x2 = np.minimum(x2[i], x2[order[1:]])
        inter_y2 = np.minimum(y2[i], y2[order[1:]])
        inter    = np.maximum(0, inter_x2 - inter_x1) * np.maximum(0, inter_y2 - inter_y1)
        iou      = inter / (areas[i] + areas[order[1:]] - inter + 1e-6)
        order    = order[1:][iou <= iou_thresh]

    return keep


class Postprocessor:
    def __init__(self, classes: list[str], conf_thresh: float, iou_thresh: float):
        self.classes     = classes
        self.conf_thresh = conf_thresh
        self.iou_thresh  = iou_thresh

    def __call__(
        self,
        raw_output: np.ndarray,
        orig_w: int, orig_h: int,
        scale: float,
        padding: tuple[int, int],
    ) -> list[Detection]:
        """
        raw_output — shape (1, 4+nc, num_anchors) or (num_anchors, 4+nc)
        """
        # Squeeze batch dimension
        pred = raw_output[0] if raw_output.ndim == 3 else raw_output
        # Transpose if needed: want (num_anchors, 4+nc)
        if pred.shape[0] < pred.shape[1]:
            pred = pred.T

        nc         = len(self.classes)
        box_xywh   = pred[:, :4]
        class_conf = pred[:, 4:4 + nc]

        # Class confidence as score
        scores     = class_conf.max(axis=1)
        class_ids  = class_conf.argmax(axis=1)

        # Confidence filter
        mask       = scores >= self.conf_thresh
        box_xywh   = box_xywh[mask]
        scores     = scores[mask]
        class_ids  = class_ids[mask]

        if len(scores) == 0:
            return []

        # xywh → xyxy (still in letterboxed space)
        boxes_lb   = xywh_to_xyxy(box_xywh)

        # NMS per class
        keep_all   = []
        for cls_id in np.unique(class_ids):
            idx    = np.where(class_ids == cls_id)[0]
            kept   = nms(boxes_lb[idx], scores[idx], self.iou_thresh)
            keep_all.extend(idx[kept])

        detections = []
        pad_w, pad_h = padding

        for i in keep_all:
            x1lb, y1lb, x2lb, y2lb = boxes_lb[i]

            # Remove padding
            x1 = (x1lb) / scale
            y1 = (y1lb) / scale
            x2 = (x2lb - pad_w / scale) / scale   # only approximate when scale ≠ 1
            y2 = (y2lb - pad_h / scale) / scale

            # Remove letterbox padding correctly
            x1 = x1lb / scale
            y1 = y1lb / scale
            x2 = (x2lb - pad_w) / scale
            y2 = (y2lb - pad_h) / scale

            # Clip to image bounds
            x1 = max(0.0, min(x1, orig_w))
            y1 = max(0.0, min(y1, orig_h))
            x2 = max(0.0, min(x2, orig_w))
            y2 = max(0.0, min(y2, orig_h))

            area = (x2 - x1) * (y2 - y1)
            if area < 1:
                continue

            cls_id   = int(class_ids[i])
            cls_name = self.classes[cls_id] if cls_id < len(self.classes) else f"class_{cls_id}"

            detections.append(Detection(
                class_name = cls_name,
                class_id   = cls_id,
                confidence = float(scores[i]),
                bbox       = (x1, y1, x2, y2),
                bbox_norm  = (x1 / orig_w, y1 / orig_h, x2 / orig_w, y2 / orig_h),
            ))

        # Sort by confidence descending
        detections.sort(key=lambda d: d.confidence, reverse=True)
        return detections


# ── Main inference class ─────────────────────────────────────────────────────

class AnimalDetector:
    """
    Wraps CoreML model loading and inference.
    Falls back to ONNX Runtime when coremltools is not available
    (e.g., on Linux CI machines).
    """

    def __init__(
        self,
        model_path:    Optional[str] = None,
        config_path:   Optional[str] = None,
        conf_threshold: Optional[float] = None,
        iou_threshold:  Optional[float] = None,
        compute_units:  Optional[str]   = None,
    ):
        self.cfg          = self._load_config(config_path or str(CONFIG_PATH))
        self.model_path   = Path(model_path or MODEL_PATH)
        self.classes      = self.cfg["classes"]
        self.conf_thresh  = conf_threshold  or self.cfg["model"]["confidence_threshold"]
        self.iou_thresh   = iou_threshold   or self.cfg["model"]["iou_threshold"]
        self.compute      = compute_units   or self.cfg["model"]["compute_units"]
        self.input_size   = self.cfg["model"]["input_size"][0]

        self._model       = None
        self._backend     = None  # "coreml" | "onnx"

        self.preprocessor = Preprocessor(self.input_size)
        self.postprocessor= Postprocessor(self.classes, self.conf_thresh, self.iou_thresh)

        self._load_model()

    # ── Internals ────────────────────────────────────────────────────────────

    @staticmethod
    def _load_config(path: str) -> dict:
        with open(path) as f:
            return json.load(f)

    def _load_model(self):
        if not self.model_path.exists():
            raise FileNotFoundError(
                f"Model not found: {self.model_path}\n"
                "Run scripts/export_coreml.py to generate it."
            )

        # Try CoreML first (macOS only)
        try:
            import coremltools as ct
            compute_map = {
                "cpuOnly":           ct.ComputeUnit.CPU_ONLY,
                "cpuAndGPU":         ct.ComputeUnit.CPU_AND_GPU,
                "all":               ct.ComputeUnit.ALL,
                "cpuAndNeuralEngine":ct.ComputeUnit.CPU_AND_NE,
            }
            compute   = compute_map.get(self.compute, ct.ComputeUnit.CPU_AND_NE)
            self._model   = ct.models.MLModel(
                str(self.model_path), compute_units=compute
            )
            self._backend = "coreml"
            print(f"✓ Loaded CoreML model  [{self.compute}]  ({self.model_path.name})")
            return
        except (ImportError, Exception) as e:
            print(f"⚠  CoreML unavailable ({e}), trying ONNX Runtime …")

        # Fall back to ONNX Runtime (Linux / Windows / CI)
        try:
            import onnxruntime as ort
            onnx_path = self.model_path.with_suffix(".onnx")
            if not onnx_path.exists():
                raise FileNotFoundError(f"ONNX model not found: {onnx_path}")
            providers     = ["CUDAExecutionProvider", "CPUExecutionProvider"]
            self._model   = ort.InferenceSession(str(onnx_path), providers=providers)
            self._backend = "onnx"
            print(f"✓ Loaded ONNX model via ONNX Runtime  ({onnx_path.name})")
        except ImportError:
            raise RuntimeError(
                "Neither coremltools nor onnxruntime is available. "
                "Install one of them to run inference."
            )

    def _run_coreml(self, blob: np.ndarray) -> np.ndarray:
        """Run inference via CoreML Predictions API."""
        import coremltools as ct
        # CoreML expects NHWC PIL Image or a dict of named inputs
        inp = {self.cfg["model"]["input_name"]: blob}
        out = self._model.predict(inp)
        # Return the first output tensor
        key = list(out.keys())[0]
        return np.array(out[key])

    def _run_onnx(self, blob: np.ndarray) -> np.ndarray:
        """Run inference via ONNX Runtime."""
        inp_name = self._model.get_inputs()[0].name
        outputs  = self._model.run(None, {inp_name: blob})
        return outputs[0]

    # ── Public API ───────────────────────────────────────────────────────────

    def detect(self, image: np.ndarray) -> InferenceResult:
        """
        Detect animals in a BGR image (as returned by cv2.imread / VideoCapture).

        Args:
            image: BGR numpy array, any resolution.

        Returns:
            InferenceResult with detections and timing info.
        """
        if image is None or image.size == 0:
            raise ValueError("Empty image passed to detect()")

        orig_h, orig_w = image.shape[:2]

        t0 = time.perf_counter()

        blob, scale, padding = self.preprocessor(image)

        if self._backend == "coreml":
            raw = self._run_coreml(blob)
        else:
            raw = self._run_onnx(blob)

        detections = self.postprocessor(raw, orig_w, orig_h, scale, padding)

        latency_ms = (time.perf_counter() - t0) * 1000

        return InferenceResult(
            detections = detections,
            latency_ms = latency_ms,
            image_w    = orig_w,
            image_h    = orig_h,
        )

    def detect_path(self, image_path: str | Path) -> InferenceResult:
        img = cv2.imread(str(image_path))
        if img is None:
            raise IOError(f"Could not read image: {image_path}")
        return self.detect(img)

    def draw_detections(self, image: np.ndarray, result: InferenceResult) -> np.ndarray:
        """Draw bounding boxes and labels on a BGR image."""
        colors = self.cfg.get("class_colors", {})
        out    = image.copy()

        for det in result.detections:
            x1, y1, x2, y2 = [int(v) for v in det.bbox]
            hex_col = colors.get(det.class_name, "#00FF00").lstrip("#")
            r, g, b = int(hex_col[0:2], 16), int(hex_col[2:4], 16), int(hex_col[4:6], 16)
            color   = (b, g, r)  # BGR for OpenCV

            cv2.rectangle(out, (x1, y1), (x2, y2), color, 2)
            label = f"{det.class_name} {det.confidence:.0%}"
            (lw, lh), baseline = cv2.getTextSize(label, cv2.FONT_HERSHEY_SIMPLEX, 0.55, 1)
            cv2.rectangle(out, (x1, y1 - lh - baseline - 4), (x1 + lw, y1), color, -1)
            cv2.putText(
                out, label, (x1, y1 - baseline - 2),
                cv2.FONT_HERSHEY_SIMPLEX, 0.55, (255, 255, 255), 1,
                lineType=cv2.LINE_AA,
            )

        # Timing overlay
        cv2.putText(
            out, f"{result.latency_ms:.1f} ms", (10, 24),
            cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2, cv2.LINE_AA,
        )
        return out


# ── CLI ──────────────────────────────────────────────────────────────────────

def main():
    p = argparse.ArgumentParser(description="Run animal detector on an image or camera")
    p.add_argument("--image",   help="Path to an image file")
    p.add_argument("--camera",  help="Camera index (int) or RTSP URL")
    p.add_argument("--model",   help="Path to .mlpackage (overrides config)")
    p.add_argument("--conf",    type=float, help="Confidence threshold override")
    p.add_argument("--iou",     type=float, help="IoU threshold override")
    p.add_argument("--output",  help="Save annotated image to this path")
    p.add_argument("--json",    action="store_true", help="Print results as JSON")
    args = p.parse_args()

    detector = AnimalDetector(
        model_path    = args.model,
        conf_threshold= args.conf,
        iou_threshold = args.iou,
    )

    if args.image:
        result = detector.detect_path(args.image)
        if args.json:
            print(json.dumps(result.to_dict(), indent=2))
        else:
            print(f"Found {len(result.detections)} animal(s) in {result.latency_ms:.1f} ms")
            for d in result.detections:
                print(f"  {d.class_name:<12}  {d.confidence:.1%}  {[int(v) for v in d.bbox]}")

        if args.output:
            img = cv2.imread(args.image)
            annotated = detector.draw_detections(img, result)
            cv2.imwrite(args.output, annotated)
            print(f"Saved annotated image to {args.output}")

    elif args.camera is not None:
        src = int(args.camera) if args.camera.isdigit() else args.camera
        cap = cv2.VideoCapture(src)
        if not cap.isOpened():
            raise RuntimeError(f"Cannot open camera: {src}")

        print("Streaming — press Q to quit")
        while True:
            ret, frame = cap.read()
            if not ret:
                break
            result    = detector.detect(frame)
            annotated = detector.draw_detections(frame, result)
            cv2.imshow("Animal Detector", annotated)
            if cv2.waitKey(1) & 0xFF == ord("q"):
                break

        cap.release()
        cv2.destroyAllWindows()

    else:
        p.print_help()


if __name__ == "__main__":
    main()
