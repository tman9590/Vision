#!/usr/bin/env python3
"""
train.py
--------
Fine-tunes YOLOv8 on the animal detection dataset, then validates and
saves the best checkpoint to runs/train/weights/best.pt.

Requirements:
    pip install ultralytics

Usage:
    # Quick smoke-test (5 epochs)
    python scripts/train.py --data data/dataset.yaml --epochs 5 --batch 8

    # Full training run
    python scripts/train.py --data data/dataset.yaml --epochs 100 --batch 16

    # Resume an interrupted run
    python scripts/train.py --resume runs/train/weights/last.pt
"""

import argparse
import json
import sys
from pathlib import Path

ROOT = Path(__file__).parent.parent
CONFIG_PATH = ROOT / "config.json"


def load_config() -> dict:
    with open(CONFIG_PATH) as f:
        return json.load(f)


def parse_args(cfg: dict):
    t = cfg["training"]
    p = argparse.ArgumentParser(description="Train animal detector (YOLOv8 → CoreML)")

    p.add_argument("--data",    default="data/dataset.yaml",  help="Path to dataset YAML")
    p.add_argument("--model",   default=t["base_model"],       help="Base YOLO checkpoint (.pt)")
    p.add_argument("--epochs",  type=int,   default=t["epochs"])
    p.add_argument("--imgsz",   type=int,   default=t["imgsz"])
    p.add_argument("--batch",   type=int,   default=t["batch"])
    p.add_argument("--patience",type=int,   default=t["patience"])
    p.add_argument("--project", default="runs",                help="Output root")
    p.add_argument("--name",    default="train",               help="Run name")
    p.add_argument("--resume",  default=None,                  help="Resume from checkpoint")
    p.add_argument("--device",  default="",                    help="cuda / mps / cpu / ''")
    p.add_argument("--workers", type=int, default=4)
    p.add_argument("--amp",     action="store_true", default=True, help="Mixed precision")
    p.add_argument("--exist_ok",action="store_true", default=False)
    return p.parse_args()


def main():
    try:
        from ultralytics import YOLO
    except ImportError:
        sys.exit("✗ ultralytics not installed. Run: pip install ultralytics")

    cfg  = load_config()
    args = parse_args(cfg)
    t    = cfg["training"]

    if args.resume:
        print(f"Resuming from {args.resume}")
        model = YOLO(args.resume)
    else:
        print(f"Starting from base model: {args.model}")
        model = YOLO(args.model)

    # ── Hyperparameters pulled from config.json ──────────────────────────────
    results = model.train(
        data        = args.data,
        epochs      = args.epochs,
        imgsz       = args.imgsz,
        batch       = args.batch,
        patience    = args.patience,
        optimizer   = t["optimizer"],
        lr0         = t["lr0"],
        lrf         = t["lrf"],
        momentum    = t["momentum"],
        weight_decay= t["weight_decay"],
        augment     = t["augment"],
        mosaic      = t["mosaic"],
        mixup       = t["mixup"],
        copy_paste  = t["copy_paste"],
        hsv_h       = t["hsv_h"],
        hsv_s       = t["hsv_s"],
        hsv_v       = t["hsv_v"],
        degrees     = t["degrees"],
        translate   = t["translate"],
        scale       = t["scale"],
        fliplr      = t["fliplr"],
        flipud      = t["flipud"],
        project     = args.project,
        name        = args.name,
        device      = args.device if args.device else None,
        workers     = args.workers,
        amp         = args.amp,
        exist_ok    = args.exist_ok,
        plots       = True,
        save        = True,
        save_period = 10,
        val         = True,
        verbose     = True,
    )

    # ── Print summary ────────────────────────────────────────────────────────
    best_pt = Path(args.project) / args.name / "weights" / "best.pt"
    print("\n" + "═" * 60)
    print("Training complete!")
    print(f"  Best checkpoint : {best_pt}")
    print(f"  mAP@0.5        : {results.results_dict.get('metrics/mAP50(B)', 'N/A'):.4f}")
    print(f"  mAP@0.5:0.95   : {results.results_dict.get('metrics/mAP50-95(B)', 'N/A'):.4f}")
    print("═" * 60)
    print(f"\nNext: python scripts/export_coreml.py --weights {best_pt}")

    # ── Validate once more on the test split ─────────────────────────────────
    val_model = YOLO(str(best_pt))
    metrics   = val_model.val(data=args.data, split="test", verbose=True)
    print(f"\nTest-set mAP@0.5: {metrics.box.map50:.4f}")


if __name__ == "__main__":
    main()
