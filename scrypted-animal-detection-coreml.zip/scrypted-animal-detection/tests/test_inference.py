#!/usr/bin/env python3
"""
tests/test_inference.py
-----------------------
Unit tests for the animal detection inference pipeline.
These tests do NOT require the actual CoreML model — they use
ONNX Runtime with a stub model to validate preprocessing,
postprocessing, and the detection pipeline.

Run:
    python -m pytest tests/ -v
"""

import json
import sys
import tempfile
from pathlib import Path

import numpy as np
import pytest

ROOT = Path(__file__).parent.parent
sys.path.insert(0, str(ROOT / "scripts"))

from inference import (
    Detection,
    InferenceResult,
    Preprocessor,
    Postprocessor,
    nms,
    xywh_to_xyxy,
)


# ── Fixtures ─────────────────────────────────────────────────────────────────

@pytest.fixture
def config():
    with open(ROOT / "config.json") as f:
        return json.load(f)


@pytest.fixture
def classes(config):
    return config["classes"]


@pytest.fixture
def preprocessor():
    return Preprocessor(target=640)


@pytest.fixture
def postprocessor(classes):
    return Postprocessor(classes, conf_thresh=0.40, iou_thresh=0.45)


@pytest.fixture
def random_bgr():
    """Random 1080p BGR image."""
    rng = np.random.default_rng(42)
    return rng.integers(0, 255, (1080, 1920, 3), dtype=np.uint8)


# ── Config tests ──────────────────────────────────────────────────────────────

class TestConfig:
    def test_has_required_keys(self, config):
        for key in ("model", "classes", "training", "export", "scrypted"):
            assert key in config, f"Missing top-level key: {key}"

    def test_classes_count(self, config):
        assert len(config["classes"]) == 20

    def test_no_duplicate_classes(self, config):
        assert len(config["classes"]) == len(set(config["classes"]))

    def test_model_input_size(self, config):
        w, h = config["model"]["input_size"]
        assert w == h == 640

    def test_thresholds_in_range(self, config):
        assert 0 < config["model"]["confidence_threshold"] < 1
        assert 0 < config["model"]["iou_threshold"] < 1

    def test_class_colors_match_classes(self, config):
        missing = [c for c in config["classes"] if c not in config.get("class_colors", {})]
        assert missing == [], f"Missing class colors: {missing}"


# ── Preprocessor tests ────────────────────────────────────────────────────────

class TestPreprocessor:
    def test_output_shape_landscape(self, preprocessor, random_bgr):
        blob, scale, padding = preprocessor(random_bgr)
        assert blob.shape == (1, 3, 640, 640)

    def test_output_dtype(self, preprocessor, random_bgr):
        blob, _, _ = preprocessor(random_bgr)
        assert blob.dtype == np.float32

    def test_normalised_range(self, preprocessor, random_bgr):
        blob, _, _ = preprocessor(random_bgr)
        assert blob.min() >= 0.0
        assert blob.max() <= 1.0

    def test_square_image(self, preprocessor):
        img = np.zeros((640, 640, 3), dtype=np.uint8)
        blob, scale, (pw, ph) = preprocessor(img)
        assert scale == pytest.approx(1.0, abs=0.01)
        assert pw == 0
        assert ph == 0

    def test_portrait_image(self, preprocessor):
        img = np.zeros((1280, 720, 3), dtype=np.uint8)
        blob, scale, _ = preprocessor(img)
        assert blob.shape == (1, 3, 640, 640)
        assert scale == pytest.approx(640 / 1280, abs=0.01)


# ── Box utilities ─────────────────────────────────────────────────────────────

class TestBoxUtils:
    def test_xywh_to_xyxy(self):
        boxes = np.array([[100, 100, 50, 50]], dtype=np.float32)  # cx, cy, w, h
        expected = np.array([[75, 75, 125, 125]], dtype=np.float32)
        result = xywh_to_xyxy(boxes)
        np.testing.assert_allclose(result, expected)

    def test_nms_removes_duplicate(self):
        # Two heavily overlapping boxes
        boxes  = np.array([[0, 0, 100, 100], [5, 5, 105, 105]], dtype=np.float32)
        scores = np.array([0.9, 0.8])
        keep   = nms(boxes, scores, iou_thresh=0.5)
        assert len(keep) == 1
        assert keep[0] == 0  # higher confidence kept

    def test_nms_keeps_separate(self):
        # Two non-overlapping boxes
        boxes  = np.array([[0, 0, 50, 50], [200, 200, 250, 250]], dtype=np.float32)
        scores = np.array([0.9, 0.85])
        keep   = nms(boxes, scores, iou_thresh=0.5)
        assert len(keep) == 2

    def test_nms_empty(self):
        boxes  = np.empty((0, 4), dtype=np.float32)
        scores = np.empty(0)
        keep   = nms(boxes, scores, iou_thresh=0.5)
        assert keep == []


# ── Postprocessor tests ───────────────────────────────────────────────────────

class TestPostprocessor:
    def _make_raw(self, nc: int = 20, n: int = 8400) -> np.ndarray:
        """Synthetic raw model output (1, 4+nc, n)."""
        rng = np.random.default_rng(7)
        raw = rng.random((1, 4 + nc, n), dtype=np.float32) * 0.3
        # Inject one confident detection at anchor 0
        raw[0, 0, 0] = 320.0   # cx
        raw[0, 1, 0] = 320.0   # cy
        raw[0, 2, 0] = 100.0   # w
        raw[0, 3, 0] = 100.0   # h
        raw[0, 4, 0] = 0.95    # class 0 (bear)
        return raw

    def test_finds_injected_detection(self, postprocessor):
        raw  = self._make_raw(20, 8400)
        dets = postprocessor(raw, 1920, 1080, scale=1.0, padding=(0, 0))
        assert len(dets) >= 1
        top = dets[0]
        assert top.class_name == "bear"
        assert top.confidence >= 0.90

    def test_respects_conf_threshold(self, classes):
        pp   = Postprocessor(classes, conf_thresh=0.99, iou_thresh=0.45)
        rng  = np.random.default_rng(42)
        raw  = rng.random((1, 24, 8400), dtype=np.float32) * 0.5  # all < 0.99
        dets = pp(raw, 640, 640, scale=1.0, padding=(0, 0))
        assert dets == []

    def test_bbox_in_image_bounds(self, postprocessor):
        raw  = self._make_raw()
        dets = postprocessor(raw, 640, 640, scale=1.0, padding=(0, 0))
        for d in dets:
            x1, y1, x2, y2 = d.bbox
            assert x1 >= 0 and y1 >= 0
            assert x2 <= 640 and y2 <= 640

    def test_normalised_bbox_range(self, postprocessor):
        raw  = self._make_raw()
        dets = postprocessor(raw, 640, 640, scale=1.0, padding=(0, 0))
        for d in dets:
            for v in d.bbox_norm:
                assert 0.0 <= v <= 1.0


# ── Detection dataclass tests ─────────────────────────────────────────────────

class TestDetection:
    def _make_det(self):
        return Detection(
            class_name = "dog",
            class_id   = 5,
            confidence = 0.876,
            bbox       = (10.0, 20.0, 110.0, 120.0),
            bbox_norm  = (0.01, 0.02, 0.11, 0.12),
        )

    def test_to_dict_keys(self):
        d = self._make_det()
        keys = d.to_dict().keys()
        for k in ("class", "class_id", "confidence", "bbox", "bbox_norm"):
            assert k in keys

    def test_to_scrypted_keys(self):
        d   = self._make_det()
        out = d.to_scrypted()
        assert "className"    in out
        assert "score"        in out
        assert "boundingBox"  in out
        bb = out["boundingBox"]
        for k in ("x", "y", "width", "height"):
            assert k in bb

    def test_to_scrypted_dimensions(self):
        d   = self._make_det()
        out = d.to_scrypted()
        bb  = out["boundingBox"]
        assert bb["width"]  == pytest.approx(100.0)
        assert bb["height"] == pytest.approx(100.0)


# ── InferenceResult tests ─────────────────────────────────────────────────────

class TestInferenceResult:
    def test_animals_present_dedup(self):
        dets = [
            Detection("cat", 2, 0.9, (0,0,50,50), (0,0,.5,.5)),
            Detection("cat", 2, 0.7, (10,10,60,60), (0,0,.5,.5)),
            Detection("dog", 5, 0.8, (100,100,200,200), (0,0,.5,.5)),
        ]
        result = InferenceResult(detections=dets, latency_ms=12.3, image_w=640, image_h=480)
        assert sorted(result.animals_present) == ["cat", "dog"]

    def test_to_dict_structure(self):
        result = InferenceResult(latency_ms=5.0, image_w=1280, image_h=720)
        d = result.to_dict()
        assert "detections"      in d
        assert "animals_present" in d
        assert "count"           in d
        assert "latency_ms"      in d
